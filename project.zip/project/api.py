from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import os
from urllib.parse import parse_qs

class MusicAPIHandler(BaseHTTPRequestHandler):
    def _set_headers(self, status_code=200):
        self.send_response(status_code)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def do_OPTIONS(self):
        self._set_headers()

    def do_GET(self):
        if self.path == '/health':
            self._set_headers()
            response = {'status': 'healthy'}
            self.wfile.write(json.dumps(response).encode())
        else:
            self._set_headers(404)
            response = {'error': 'Not found'}
            self.wfile.write(json.dumps(response).encode())

    def do_POST(self):
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        request_data = json.loads(post_data)

        if self.path == '/generate':
            # Mock response for development
            response = {
                'clips': [{
                    'id': '123',
                    'audio_url': 'https://example.com/audio.mp3',
                    'status': 'completed',
                    'title': request_data.get('title', 'Generated Music'),
                    'created_at': '2024-03-14T12:00:00Z',
                    'is_public': False
                }]
            }
            self._set_headers()
            self.wfile.write(json.dumps(response).encode())
        elif self.path == '/get_song':
            # Mock response for development
            response = {
                'id': request_data['song_id'],
                'audio_url': 'https://example.com/audio.mp3',
                'status': 'completed',
                'title': 'Generated Music',
                'created_at': '2024-03-14T12:00:00Z',
                'is_public': False
            }
            self._set_headers()
            self.wfile.write(json.dumps(response).encode())
        else:
            self._set_headers(404)
            response = {'error': 'Not found'}
            self.wfile.write(json.dumps(response).encode())

def run(server_class=HTTPServer, handler_class=MusicAPIHandler, port=8080):
    server_address = ('', port)
    httpd = server_class(server_address, handler_class)
    print(f'Starting server on port {port}...')
    httpd.serve_forever()

if __name__ == '__main__':
    run()