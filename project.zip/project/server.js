import express from 'express';
import cors from 'cors';
import axios from 'axios';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const port = 8080;

app.use(cors());
app.use(express.json());

const sunoApi = axios.create({
  baseURL: 'https://app.suno.ai/api',
  headers: {
    'Cookie': `__session=${process.env.SUNO_COOKIE}`,
    'Content-Type': 'application/json'
  }
});

app.get('/health', (req, res) => {
  res.json({ status: 'healthy' });
});

app.post('/generate', async (req, res) => {
  try {
    const response = await sunoApi.post('/generate', {
      prompt: req.body.prompt,
      is_custom: req.body.is_custom || false,
      tags: req.body.tags,
      title: req.body.title,
      make_instrumental: req.body.make_instrumental || false,
      model_version: req.body.model_version || 'chirp-v3-5',
      wait_audio: req.body.wait_audio || true
    });
    res.json(response.data);
  } catch (error) {
    console.error('Error generating music:', error.response?.data || error.message);
    res.status(500).json({
      error: 'Failed to generate music',
      details: error.response?.data || error.message
    });
  }
});

app.post('/get_song', async (req, res) => {
  try {
    const response = await sunoApi.get(`/songs/${req.body.song_id}`);
    res.json(response.data);
  } catch (error) {
    console.error('Error getting song:', error.response?.data || error.message);
    res.status(500).json({
      error: 'Failed to get song',
      details: error.response?.data || error.message
    });
  }
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});