import React, { useState } from 'react';
import { Menu, Gift, User, Search, Mic, MessageSquare, Plus, Brain, Moon, Music, Clock, Volume2 } from 'lucide-react';
import { Toaster } from 'react-hot-toast';
import ScenarioButton from './components/ScenarioButton';
import SoundscapeButton from './components/SoundscapeButton';
import AudioPlayer from './components/AudioPlayer';
import { generateMusic, checkGenerationStatus } from './services/api';
import toast from 'react-hot-toast';

function App() {
  const [message, setMessage] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedAudioUrl, setGeneratedAudioUrl] = useState<string>();

  const handleGenerate = async () => {
    if (!message) {
      toast.error('Please enter a message to generate music');
      return;
    }
    
    setIsGenerating(true);
    try {
      const generation = await generateMusic({
        prompt: message,
        wait_audio: true,
        model_version: 'chirp-v3-5'
      });
      
      if (generation.clips && generation.clips.length > 0) {
        const clip = generation.clips[0];
        if (clip.audio_url) {
          setGeneratedAudioUrl(clip.audio_url);
          toast.success('Music generated successfully!');
        } else {
          // Poll for completion if audio_url is not immediately available
          const checkStatus = async () => {
            const status = await checkGenerationStatus(clip.id);
            if (status.audio_url) {
              setGeneratedAudioUrl(status.audio_url);
              toast.success('Music generated successfully!');
              setIsGenerating(false);
            } else if (status.status === 'failed') {
              throw new Error('Generation failed');
            } else {
              setTimeout(checkStatus, 2000); // Check again in 2 seconds
            }
          };
          await checkStatus();
        }
      } else {
        throw new Error('No clips generated');
      }
      setIsGenerating(false);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Failed to generate music');
      setIsGenerating(false);
    }
  };

  return (
    <div className="min-h-screen bg-black text-white">
      <Toaster position="top-center" />
      {/* Header */}
      <header className="p-4 flex justify-between items-center">
        <div className="flex items-center gap-4">
          <Menu className="w-6 h-6" />
          <h1 className="text-lg font-medium">Afternoon Energy Recharge</h1>
        </div>
        <div className="flex items-center gap-4">
          <Gift className="w-6 h-6" />
          <User className="w-6 h-6" />
        </div>
      </header>

      {/* Main Content */}
      <main className="px-4 py-6 pb-32">
        {/* Feature Card */}
        <div className="bg-zinc-900 rounded-xl p-6 mb-8">
          <div className="flex justify-center items-center h-40">
            <div className="text-center">
              <h2 className="text-gray-400 mb-2">WHAT'S NEW</h2>
              <h3 className="text-2xl font-bold">Autoplay</h3>
            </div>
          </div>
        </div>

        {/* Generated Audio Player */}
        {generatedAudioUrl && (
          <div className="mb-8">
            <h2 className="text-xl font-bold mb-4">Generated Music</h2>
            <AudioPlayer audioUrl={generatedAudioUrl} />
          </div>
        )}

        {/* Soundscapes Section */}
        <section className="mb-8">
          <h2 className="text-xl font-bold mb-4">Endless Soundscapes</h2>
          <div className="grid grid-cols-5 gap-4">
            <SoundscapeButton icon={Clock} label="Autoplay" locked />
            <SoundscapeButton icon={Brain} label="Colored Noise" locked />
            <SoundscapeButton icon={Music} label="Focus" />
            <SoundscapeButton icon={Volume2} label="Relax" />
            <SoundscapeButton icon={Moon} label="Sleep" />
          </div>
        </section>

        {/* Scenarios Section */}
        <section className="mb-8">
          <h2 className="text-xl font-bold mb-4">Scenarios</h2>
          <div className="flex flex-wrap gap-2">
            <ScenarioButton icon={Clock} label="Focus Timer" />
            <ScenarioButton label="Deep Work" />
            <ScenarioButton label="Read" />
            <ScenarioButton label="Power Nap" />
            <ScenarioButton label="Meditate" />
            <ScenarioButton label="ASMR" />
            <ScenarioButton label="Tinnitus Relief" />
            <ScenarioButton label="Baby Sleep" />
            <ScenarioButton label="Attention Boost" />
            <ScenarioButton label="Binaural Beats" />
            <ScenarioButton label="Brain Massage" />
          </div>
        </section>

        {/* Music Generation Section */}
        <section className="fixed bottom-0 left-0 right-0 bg-zinc-900 p-4">
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-2">
              <Plus className="w-6 h-6" />
              <Search className="w-6 h-6" />
              <input
                type="text"
                placeholder="What can I help with?"
                className="flex-1 bg-transparent outline-none"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
              />
              <MessageSquare className="w-6 h-6" />
              <Mic className="w-6 h-6" />
            </div>
            <div className="flex justify-center gap-4">
              <button
                className={`px-4 py-2 rounded-full ${
                  isGenerating ? 'bg-gray-700' : 'bg-blue-600 hover:bg-blue-700'
                }`}
                onClick={handleGenerate}
                disabled={isGenerating}
              >
                {isGenerating ? 'Generating...' : 'Generate Music'}
              </button>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

export default App;