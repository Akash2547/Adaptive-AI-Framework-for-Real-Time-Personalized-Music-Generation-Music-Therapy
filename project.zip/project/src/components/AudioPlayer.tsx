import React from 'react';
import { Play, Pause, Volume2 } from 'lucide-react';
import { useAudioPlayer } from '../hooks/useAudioPlayer';

interface AudioPlayerProps {
  audioUrl: string;
}

const AudioPlayer: React.FC<AudioPlayerProps> = ({ audioUrl }) => {
  const { isPlaying, currentTime, duration, togglePlay, seek } = useAudioPlayer(audioUrl);

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="bg-zinc-800 rounded-lg p-4">
      <div className="flex items-center gap-4">
        <button
          onClick={togglePlay}
          className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center hover:bg-blue-700 transition-colors"
        >
          {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
        </button>
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-sm text-gray-400">{formatTime(currentTime)}</span>
            <div className="flex-1 h-1 bg-zinc-700 rounded-full">
              <div
                className="h-full bg-blue-600 rounded-full relative"
                style={{ width: `${(currentTime / duration) * 100}%` }}
                onClick={(e) => {
                  const rect = e.currentTarget.getBoundingClientRect();
                  const percent = (e.clientX - rect.left) / rect.width;
                  seek(percent * duration);
                }}
              >
                <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full" />
              </div>
            </div>
            <span className="text-sm text-gray-400">{formatTime(duration)}</span>
          </div>
        </div>
        <Volume2 className="w-5 h-5 text-gray-400" />
      </div>
    </div>
  );
};

export default AudioPlayer