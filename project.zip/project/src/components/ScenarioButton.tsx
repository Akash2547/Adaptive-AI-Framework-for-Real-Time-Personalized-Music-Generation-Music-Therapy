import React from 'react';
import { DivideIcon as LucideIcon } from 'lucide-react';

interface ScenarioButtonProps {
  label: string;
  icon?: LucideIcon;
}

const ScenarioButton: React.FC<ScenarioButtonProps> = ({ label, icon: Icon }) => {
  return (
    <button className="px-4 py-2 bg-zinc-800 rounded-full hover:bg-zinc-700 transition-colors flex items-center gap-2">
      {Icon && <Icon className="w-4 h-4" />}
      <span>{label}</span>
    </button>
  );
};

export default ScenarioButton;