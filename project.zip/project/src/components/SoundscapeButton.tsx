import React from 'react';
import { DivideIcon as LucideIcon, Lock } from 'lucide-react';

interface SoundscapeButtonProps {
  icon: LucideIcon;
  label: string;
  locked?: boolean;
}

const SoundscapeButton: React.FC<SoundscapeButtonProps> = ({ icon: Icon, label, locked }) => {
  return (
    <button className="flex flex-col items-center gap-2 opacity-90 hover:opacity-100 transition-opacity">
      <div className="relative">
        <div className="w-16 h-16 bg-zinc-800 rounded-full flex items-center justify-center">
          <Icon className="w-8 h-8" />
        </div>
        {locked && (
          <div className="absolute -top-1 -right-1 w-6 h-6 bg-zinc-700 rounded-full flex items-center justify-center">
            <Lock className="w-3 h-3" />
          </div>
        )}
      </div>
      <span className="text-sm">{label}</span>
    </button>
  );
};

export default SoundscapeButton;