import axios from 'axios';

// The API URL will point to our local FastAPI server
const API_URL = 'http://localhost:8080';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  },
});

export interface GenerateMusicParams {
  prompt: string;
  is_custom?: boolean;
  tags?: string;
  title?: string;
  make_instrumental?: boolean;
  model_version?: string;
  wait_audio?: boolean;
}

export interface Clip {
  id: string;
  audio_url?: string;
  status?: string;
  title?: string;
  created_at?: string;
  is_public?: boolean;
}

export interface GenerationResponse {
  clips: Clip[];
}

export const generateMusic = async (params: GenerateMusicParams): Promise<GenerationResponse> => {
  try {
    const response = await api.post('/generate', {
      prompt: params.prompt,
      is_custom: params.is_custom || false,
      tags: params.tags,
      title: params.title,
      make_instrumental: params.make_instrumental || false,
      model_version: params.model_version || 'chirp-v3-5',
      wait_audio: params.wait_audio || true
    });
    return response.data;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      throw new Error(error.response?.data?.message || 'Failed to generate music');
    }
    throw error;
  }
};

export const checkGenerationStatus = async (songId: string): Promise<Clip> => {
  try {
    const response = await api.post('/get_song', {
      song_id: songId
    });
    return response.data;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      throw new Error(error.response?.data?.message || 'Failed to check generation status');
    }
    throw error;
  }
};